#include <stdio.h>
#include <math.h>
int main (void)
{
int raiz, contador, num;
printf("Digite um numero :");
scanf("%d", &num);
raiz = sqrt(num);
contador = raiz;
    while (contador > 1)
    {
        if (num%contador == 0)
            {printf("esse numero nao e primo");}
        else
            {printf("esse numero e primo");}
    contador --;
    }
    return 0;
}