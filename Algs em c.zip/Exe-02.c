#include <stdio.h>
int main (void)
{
int n1, n2;
printf("Digite o primeiro número : \n");
scanf("%d", &n1);
printf("Digite o segundo número :\n");
scanf("%d", &n2);
printf("A soma dos números %d e %d é igual a %d", n1, n2, n1+n2);
return 0;
}