#include <stdio.h>

int main() {
    int n = 5; // tamanho do array
    int arr[] = {5, 2, 8, 1, 6}; // array de inteiros
    int escolha, binario, decimal, digito, i;
    int pos = 0;
    int n = 8;
    printf("Digite 1 para transformar decimal para binario.\nDigite 2 para transformar binario para decimal.\n");


    switch (escolha)
    {
    case 1:
        printf("Digite o numero decimal:\n");
        scanf("%d", &digito);
        for (int i = 0; i < n; i ++){

            binario = (digito%2);
            arr[pos] = binario;
            pos++;
        }
        
        break;
    
    // Imprime os elementos do array em ordem decrescente
    for (int i = n - 1; i >= 0; i--) {
        printf("%d ", arr[i]);
    }
    case 2:
        printf("Digite o numero binario, um numero por vez:\n");
        for (int i = 0; i < n; i++){
            scanf("%d", &binario);
            arr[pos] = binario;
            pos++;
        }
    decimal = arr[0];
    default:
        break;
    
    
    }
    
    

    return 0;
}
