#include <stdio.h>

int main() 
{
//Ceclaração de variáveis
int idade;

//Dado que o programa precisa
printf("Qual a sua idade ?\n");

//Atribuição de valores as variáveis
scanf("%d", &idade);

//Condicionais
if (idade < 16)
{printf("Voce nao pode votar !");}
else if (idade > 16 && idade < 18)
{printf("Voce pode votar se quiser.");}
else if (idade > 18 && idade <= 65 )
{printf("Voce precisa votar !");}
else
{printf("Voce pode votar se quiser.");}
return 0;
}