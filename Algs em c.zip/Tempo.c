#include <stdio.h>
int main (void)
{
int horas, minutos, segundos, SegTotal;
printf("Segundos : ");
scanf("%d", &SegTotal);

horas = ((SegTotal/60)/60);
minutos = (SegTotal/60)%60;
segundos = (SegTotal%60);
printf("%d horas %d min %d segundos", horas, minutos, segundos);
return 0;

}