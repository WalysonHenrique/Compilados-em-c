#include <stdio.h>
int main (){
    int n1, n2, n3, n4;
    printf("Insira 4 numeros :\n ");
    scanf("%d", &n1);
    scanf("%d", &n2);
    scanf("%d", &n3);
    scanf("%d", &n4);
if (n1 > n2 && n1 > n3 && n1 > n4){
    printf("O maior numero e %d", n1);}
else if (n2 > n1 && n2 > n3 && n2 > n4){
    printf("O maior numero e %d", n2);}
else if (n3 > n1 && n3 > n2 && n3 > n4){
    printf("O maior numero e %d", n3);}
else 
    printf("O maior numero e %d",n4);
return 0;
}