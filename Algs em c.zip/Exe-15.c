#include <stdio.h>
#include <stdlib.h>
int main(void)
{
    int num, i, soma = 0;
    int *numDivisiveis = NULL;
    printf("Digite um numero: \n");
    scanf("%d", &num);
    numDivisiveis = realloc(numDivisiveis, sizeof(int));
    for (i = 1; i < num; i++)
    {
        if (num % i == 0)
        {   
            numDivisiveis = realloc(numDivisiveis, sizeof(int)*(i+1));
            numDivisiveis[i] = i;
        }
    }   
    for (i = 0; i < num ; i++)
    {     
        soma += (numDivisiveis[i]);
    }   
    if (soma == num)
    {   
        printf("O numero %d e um numero perfeito",num);
    }
    else
    {
        printf("O numero %d nao e um numero perfeito\n",num);
    }
  printf("\n%d", soma);  
  free(numDivisiveis);
    return 0;
}