#include <stdio.h>
int main (void)
{
    int i, numero, varAux = 1, resultado = 0;

    printf("Digite um numero inteiro: \n");
    scanf("%d", &numero);
    for (i = 1; i <= numero; i++)
    {
        if (varAux == numero)
        {
            resultado = 1;
        }
        varAux = i *(i + 1)/2;
       
    }
    if (resultado == 1)
    {
        printf("\nO numero %d e primo.\n", numero);
    }
    else
    {
        printf("\nO numero %d nao e primo.\n", numero);
    }
    return 1;
}