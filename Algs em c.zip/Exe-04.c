#include <stdio.h>
int main (void)
{
int num;
printf("Digite um número : \n");
scanf("%d", &num);
if (num%2 == 0)
    printf("É par !");
else
    printf("É ímpar !");

return 0;



}