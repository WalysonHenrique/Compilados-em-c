#include <stdio.h>
#include <math.h>
int main (void)
{
float n1, n2, n3, n4 ,media;
printf("Digite as quatro notas do aluno :\n");
scanf("%f", &n1);
scanf("%f", &n1);
scanf("%f", &n1);
scanf("%f", &n1);
media = n1+n2+n3+n4/4;
if (media >= 6 )
    printf("Aprovado !");
else
    printf("Reprovado !");
    return 0;
}