#include <stdio.h>
#include <math.h>
int main(void)
{
    int num;
    printf("Digite um numero :\n");
    scanf("%d", &num);
    printf("A raiz do numero %d e %2.f\n", num, sqrt(num));

    return 0;
}