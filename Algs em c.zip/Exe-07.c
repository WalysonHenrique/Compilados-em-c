#include <stdio.h>
int main (void)
{
float celsius;
printf("Qual a temperatura em celsius ?\n");
scanf("%f", &celsius);
printf("A temperatura em fahrenheit e %.2f.", celsius*1.8+32);
return 0;
}