#include <stdio.h>
int main (void)
{
int n = 0;
while (n < 101)
{
    if (n%2 == 0)
        printf("%d\n", n);
n ++;
}
return 0;
}