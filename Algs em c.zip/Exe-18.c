#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    int *divisores = NULL;
    int i, num, contador_divisores = 0;

    printf("Digite um numero: ");
    scanf("%d", &num);

    divisores = malloc(num * sizeof(int));
    if (divisores == NULL) {
        printf("Erro de memoria");
        return 1;
    }

    for (i = 2; i <= num / 2; i++)
    {
        if (num % i == 0)
        {
            divisores[contador_divisores] = i;
            contador_divisores++;
        }
    }

    printf("Os divisores de %d sao: ", num);
    for (i = 0; i < contador_divisores; i++)
    {
        printf("%d ", divisores[i]);
    }
    printf("\n");

    free(divisores);
return 0;
}
