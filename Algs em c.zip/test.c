#include <stdio.h>
#include <math.h>
int main (void)
{
int notas[4],media;
printf("Digite as quatro notas do aluno :\n");
scanf("%d", &notas);
scanf("%d", &notas);
scanf("%d", &notas);
scanf("%d", &notas);
media = sum(notas)/len(notas);
if (media >= 6 )
    printf("Aprovado !");
else
    printf("Reprovado !");
    return 0;
}