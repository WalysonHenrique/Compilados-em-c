#include <stdio.h>
#include <stdlib.h>
int main(void)
{
    int numDec, numBin, i = 0, tamanhoArray;
    int *binario = NULL;
    printf("Digite um numero na base decimal : \n");
    scanf("%d", &numDec);
    binario = malloc(numDec * sizeof(int));
    while (numDec > (1 << tamanhoArray))
    {
        tamanhoArray++;
    }
    binario = malloc(tamanhoArray * sizeof(int));
    while (numDec >= 1)
    {
        numBin = numDec % 2;
        numDec = numDec / 2;
        binario[i] = numBin;
        i++;
    }
    printf("O numero %d em binario e : \n", numDec);
    for (int j = i - 1; j >= 0; j--)
    {
        printf("%d ", binario[j]);
    }
    free(binario);

    return 0;
}